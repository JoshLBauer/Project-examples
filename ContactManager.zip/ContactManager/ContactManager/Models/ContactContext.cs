﻿using Microsoft.EntityFrameworkCore;

namespace ContactManager.Models
{
    public class ContactContext : DbContext
    {
        public ContactContext(DbContextOptions<ContactContext> options) : base(options) { }

        public DbSet<Contact> Contacts { get; set; } = null!;
        public DbSet<Category> Categories { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
              new Category { CategoryId = 1, Name = "Family" },
              new Category { CategoryId = 2, Name = "Friend" },
              new Category { CategoryId = 3, Name = "Work" }
            );

            modelBuilder.Entity<Contact>().HasData(
                new Contact
                {   
                    ContactId = 1,
                    Firstname = "Josh",
                    Lastname = "Bauer",
                    Phone = "(308) 555-4321",
                    Email = "jbauer5@uco.edu",
                    CategoryId = 1
                }, new Contact
                {
                    ContactId = 2,
                    Firstname = "Frank",
                    Lastname = "Moses",
                    Phone = "(216) 555-1234",
                    Email = "ImGettingThePig@email.com",
                    CategoryId = 2,
                }, new Contact
                {
                    ContactId = 3,
                    Firstname = "John",
                    Lastname = "Doe",
                    Phone = "(345) 205-0555",
                    Email = "whoAmI@email.com",
                    CategoryId = 3,
                });
        }
    }
}
