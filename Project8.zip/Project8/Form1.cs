using System.Xml.Linq;

namespace Project8
{
    public partial class Form1 : Form
    {
        List<Employee> employees = new List<Employee>();
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeButton_Click(object sender, EventArgs e)
        {
            decimal tempSal = -1;
            int tempID = -1;
            if (decimal.TryParse(salaryBox.Text, out tempSal) && int.TryParse(employeeIDBox.Text, out tempID))
            {
                employees.Add(new Employee(nameBox.Text, tempID, tempSal));
                employeeList.Items.Clear();
                foreach (var i in employees)
                {
                    employeeList.Items.Add(i.GetDetails());
                }
            }
            else
            {
                MessageBox.Show("invalid input");
            }


        }

        private void managerButton_Click(object sender, EventArgs e)
        {
            decimal tempSal = -1;
            int tempID = -1;
            int tempCount = -1;
            decimal tempBonus = -1;
            if (decimal.TryParse(salaryBox.Text, out tempSal) && int.TryParse(employeeIDBox.Text, out tempID) && decimal.TryParse(bonusBox.Text, out tempBonus) && int.TryParse(teamSizeBox.Text, out tempCount))
            {
                employees.Add(new Manager(nameBox.Text, tempID, tempSal, tempCount, tempBonus));
                employeeList.Items.Clear();
                foreach (var i in employees)
                {
                    employeeList.Items.Add(i.GetDetails());
                }
            }
            else
            {
                MessageBox.Show("invalid input");
            }
        }
    }
}

public class Employee
{
    public string name;
    public int employeeID;
    public decimal salary;
    public Employee(string name, int eID, decimal salary)
    {
        this.name = name;
        this.employeeID = eID;
        this.salary = salary;
    }

    public virtual string GetDetails()
    {
        string temp = "Employee: " + name + ", " + employeeID + ", $" + salary;

        return temp;
    }
}

public class Manager : Employee
{
    int teamSize;
    decimal bonus;
    public Manager(string name, int eID, decimal salary, int ts, decimal bonus) : base(name, eID, salary)
    {
        this.teamSize = ts;
        this.bonus = bonus;
    }

    public override string GetDetails()
    {
        string temp = "Manager: " + name + ", " + employeeID + ", $" + salary + ", bonus: $" + bonus + ", Employees: " + teamSize;

        return temp;
    }
}