﻿namespace Project8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nameLabel = new Label();
            employeeIDLabel = new Label();
            salaryLabel = new Label();
            nameBox = new TextBox();
            employeeIDBox = new TextBox();
            salaryBox = new TextBox();
            employeeGroup = new GroupBox();
            teamSizeLabel = new Label();
            bonusLabel = new Label();
            teamSizeBox = new TextBox();
            bonusBox = new TextBox();
            managerBox = new GroupBox();
            employeeButton = new Button();
            managerButton = new Button();
            employeeList = new ListBox();
            employeeGroup.SuspendLayout();
            managerBox.SuspendLayout();
            SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new Point(18, 26);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(45, 15);
            nameLabel.TabIndex = 0;
            nameLabel.Text = "Name: ";
            // 
            // employeeIDLabel
            // 
            employeeIDLabel.AutoSize = true;
            employeeIDLabel.Location = new Point(18, 59);
            employeeIDLabel.Name = "employeeIDLabel";
            employeeIDLabel.Size = new Size(79, 15);
            employeeIDLabel.TabIndex = 1;
            employeeIDLabel.Text = "Employee ID: ";
            // 
            // salaryLabel
            // 
            salaryLabel.AutoSize = true;
            salaryLabel.Location = new Point(18, 94);
            salaryLabel.Name = "salaryLabel";
            salaryLabel.Size = new Size(47, 15);
            salaryLabel.TabIndex = 2;
            salaryLabel.Text = "Salary:  ";
            // 
            // nameBox
            // 
            nameBox.Location = new Point(103, 23);
            nameBox.Name = "nameBox";
            nameBox.Size = new Size(169, 23);
            nameBox.TabIndex = 0;
            // 
            // employeeIDBox
            // 
            employeeIDBox.Location = new Point(103, 56);
            employeeIDBox.Name = "employeeIDBox";
            employeeIDBox.Size = new Size(169, 23);
            employeeIDBox.TabIndex = 1;
            // 
            // salaryBox
            // 
            salaryBox.Location = new Point(103, 91);
            salaryBox.Name = "salaryBox";
            salaryBox.Size = new Size(169, 23);
            salaryBox.TabIndex = 2;
            // 
            // employeeGroup
            // 
            employeeGroup.Controls.Add(salaryBox);
            employeeGroup.Controls.Add(employeeIDBox);
            employeeGroup.Controls.Add(nameBox);
            employeeGroup.Controls.Add(salaryLabel);
            employeeGroup.Controls.Add(employeeIDLabel);
            employeeGroup.Controls.Add(nameLabel);
            employeeGroup.Location = new Point(17, 19);
            employeeGroup.Name = "employeeGroup";
            employeeGroup.Size = new Size(308, 142);
            employeeGroup.TabIndex = 3;
            employeeGroup.TabStop = false;
            employeeGroup.Text = "Employee Info";
            // 
            // teamSizeLabel
            // 
            teamSizeLabel.AutoSize = true;
            teamSizeLabel.Location = new Point(18, 26);
            teamSizeLabel.Name = "teamSizeLabel";
            teamSizeLabel.Size = new Size(64, 15);
            teamSizeLabel.TabIndex = 4;
            teamSizeLabel.Text = "Team Size: ";
            // 
            // bonusLabel
            // 
            bonusLabel.AutoSize = true;
            bonusLabel.Location = new Point(18, 67);
            bonusLabel.Name = "bonusLabel";
            bonusLabel.Size = new Size(49, 15);
            bonusLabel.TabIndex = 5;
            bonusLabel.Text = "Bonus:  ";
            // 
            // teamSizeBox
            // 
            teamSizeBox.Location = new Point(103, 23);
            teamSizeBox.Name = "teamSizeBox";
            teamSizeBox.Size = new Size(169, 23);
            teamSizeBox.TabIndex = 3;
            // 
            // bonusBox
            // 
            bonusBox.Location = new Point(103, 64);
            bonusBox.Name = "bonusBox";
            bonusBox.Size = new Size(169, 23);
            bonusBox.TabIndex = 6;
            // 
            // managerBox
            // 
            managerBox.Controls.Add(bonusBox);
            managerBox.Controls.Add(teamSizeBox);
            managerBox.Controls.Add(bonusLabel);
            managerBox.Controls.Add(teamSizeLabel);
            managerBox.Location = new Point(17, 183);
            managerBox.Name = "managerBox";
            managerBox.Size = new Size(308, 108);
            managerBox.TabIndex = 7;
            managerBox.TabStop = false;
            managerBox.Text = "Manager Info";
            // 
            // employeeButton
            // 
            employeeButton.Location = new Point(35, 338);
            employeeButton.Name = "employeeButton";
            employeeButton.Size = new Size(110, 26);
            employeeButton.TabIndex = 8;
            employeeButton.Text = "Create Employee";
            employeeButton.UseVisualStyleBackColor = true;
            employeeButton.Click += employeeButton_Click;
            // 
            // managerButton
            // 
            managerButton.Location = new Point(205, 338);
            managerButton.Name = "managerButton";
            managerButton.Size = new Size(110, 26);
            managerButton.TabIndex = 9;
            managerButton.Text = "Create Manager";
            managerButton.UseVisualStyleBackColor = true;
            managerButton.Click += managerButton_Click;
            // 
            // employeeList
            // 
            employeeList.FormattingEnabled = true;
            employeeList.ItemHeight = 15;
            employeeList.Location = new Point(393, 38);
            employeeList.Name = "employeeList";
            employeeList.Size = new Size(456, 319);
            employeeList.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(885, 385);
            Controls.Add(employeeList);
            Controls.Add(managerButton);
            Controls.Add(employeeButton);
            Controls.Add(managerBox);
            Controls.Add(employeeGroup);
            Name = "Form1";
            Text = "New Employee Form";
            employeeGroup.ResumeLayout(false);
            employeeGroup.PerformLayout();
            managerBox.ResumeLayout(false);
            managerBox.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label nameLabel;
        private Label employeeIDLabel;
        private Label salaryLabel;
        private TextBox nameBox;
        private TextBox employeeIDBox;
        private TextBox salaryBox;
        private GroupBox employeeGroup;
        private Label teamSizeLabel;
        private Label bonusLabel;
        private TextBox teamSizeBox;
        private TextBox bonusBox;
        private GroupBox managerBox;
        private Button employeeButton;
        private Button managerButton;
        private ListBox employeeList;
    }
}