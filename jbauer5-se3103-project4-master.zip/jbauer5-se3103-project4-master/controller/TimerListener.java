package controller;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import model.Bullet;
import model.Shooter;
import model.ObserverPattern.GameObserver;
import view.GameBoard;
import view.TextDraw;

public class TimerListener implements ActionListener {

    public enum EventType {
        KEY_RIGHT, KEY_LEFT, KEY_SPACE
    }

    private GameBoard gameBoard;
    private LinkedList<EventType> eventQueue;
    private static final int BOMB_DROP_FREQ = 20;
    private int frameCounter = 0;
    private int bonus = 0;
    private Shooter addS;
    GameObserver observer;

    public TimerListener(GameBoard gameBoard){
        this.gameBoard = gameBoard;
        eventQueue = new LinkedList<>();

          
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(frameCounter == 0) {
            observer = new GameObserver(gameBoard); //add observer
            gameBoard.getEnemyComposite().register(observer);
        }
        ++frameCounter;
        update();
        processEventQueue();
        processCollision();
        gameBoard.getEnemyComposite().notifyObserver();
        
        //add extra shooters
        if(gameBoard.getScore() == 100 && bonus == 0){
            gameBoard.setAddS(gameBoard.getShooter().x, gameBoard.getShooter().y, 10);
            addS = gameBoard.getAddS();
            gameBoard.getCanvas().getGameElements().add(addS);
            bonus++;
        }
        
        //check to see if enemy out of bounds
        if(gameBoard.getEnemyComposite().isEnemeyOutOfBounds()){
            gameBoard.getTimer().stop();
            gameBoard.getCanvas().getGameElements().add(new TextDraw("You Lost", 225, 150, Color.yellow, 30));
            gameBoard.getCanvas().getGameElements().add(new TextDraw("Final Score: " + gameBoard.getScore(), 200, 175, Color.yellow, 20));
        }
        //game won
        if(gameBoard.getEnemyComposite().noMoreEnemeys()){
            gameBoard.getTimer().stop();
            gameBoard.getCanvas().getGameElements().add(new TextDraw("You Won", 225, 150, Color.yellow, 30));
            gameBoard.getCanvas().getGameElements().add(new TextDraw("Final Score: " + gameBoard.getScore(), 200, 175, Color.yellow, 20));
        }
        //game lost: you died
        if(gameBoard.getShooter().isDead()){
            gameBoard.getTimer().stop();
            gameBoard.getCanvas().getGameElements().add(new TextDraw("You Lost", 225, 150, Color.yellow, 30));
            gameBoard.getCanvas().getGameElements().add(new TextDraw("Final Score: " + gameBoard.getScore(), 200, 175, Color.yellow, 20));
        }

        
        gameBoard.getCanvas().repaint();
        
    }

    private void processEventQueue(){
        while(!eventQueue.isEmpty()){
            var e = eventQueue.getFirst();
            eventQueue.removeFirst();
            Shooter shooter = gameBoard.getShooter();
            if(shooter == null) return;

            switch(e) {
                case KEY_LEFT:
                    shooter.moveLeft();
                    if(addS != null){
                        addS.moveLeft();
                    }
                    break;
                case KEY_RIGHT:
                    shooter.moveRight();
                    if(addS != null){
                        addS.moveRight();
                    }
                    break;
                case KEY_SPACE:
                    if(shooter.canFireMoreBullet()){
                        shooter.getWeapons().add(new Bullet(shooter.x, shooter.y));
                    }
                    if(addS != null && addS.canFireMoreBullet()){
                        addS.getWeapons().add(new Bullet(shooter.x+30, shooter.y));
                        addS.getWeapons().add(new Bullet(shooter.x-50, shooter.y));
                    }
                    break;
            }
        }

        if(frameCounter == BOMB_DROP_FREQ) {
            gameBoard.getEnemyComposite().dropBombs();
            frameCounter = 0;
        }
    }

    private void processCollision(){
        var shooter = gameBoard.getShooter();
        var defence = gameBoard.getDefence();
        var enemyComposite = gameBoard.getEnemyComposite();
        //shooter.removeBulletsOutOFBound();
        enemyComposite.removeBombsOutOfBound();
        if(addS == null){
            shooter.removeBulletsOutOFBound();
            enemyComposite.processCollision(shooter, defence);
        }else{
            shooter.removeBulletsOutOFBound();
            addS.removeBulletsOutOFBound();
            enemyComposite.processCollision2(shooter, defence, addS);
        }
    }

    private void update(){
        for(var e: gameBoard.getCanvas().getGameElements()){
            e.animate();
        }
    }

    public LinkedList<EventType> getEventQueue() {
        return eventQueue;
    }
    
    public void setBonus(int bonus) {
        this.bonus = bonus;
    }
}
