package model.StrategyPattern;

import java.awt.Color;
import java.awt.Graphics2D;
public class RegBomb implements Strategy{

    @Override
    public void bombRender(Graphics2D g2, int x, int y, Color color, boolean filled, int width, int height) {
        g2.setColor(color);
        if(filled){
            g2.fillOval(x, y, width, height);
        }else{
            g2.drawOval(x, y, width, height);
        }
        
    }
    
}
