package model.StrategyPattern;
import java.awt.Color;
import java.awt.Graphics2D;

public interface Strategy {
    
    public void bombRender(Graphics2D g2, int x, int y, Color color, boolean filled, int width, int height);
}

