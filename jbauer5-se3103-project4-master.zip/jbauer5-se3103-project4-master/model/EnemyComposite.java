package model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

import model.ObserverPattern.Observer;
import model.ObserverPattern.Subject;
import model.StrategyPattern.RegBomb;
import model.StrategyPattern.WideBomb;
import view.GameBoard;

public class EnemyComposite extends GameElement implements Subject{

    public static final int NROWS = 2;
    public static final int NCOLS = 10;
    public static final int ENEMY_SIZE = 20;
    public static final int UNIT_MOVE = 5;

    private ArrayList<Observer> observers = new ArrayList<>();
    private ArrayList<ArrayList<GameElement>> rows;
    private ArrayList<GameElement> bombs;
    private boolean movingToRight = true;
    private Random random = new Random();
    public int kills = 0;
    private int enemies = 0;

    public EnemyComposite(){
        rows = new ArrayList<>();
        bombs = new ArrayList<>();

        for(int r = 0; r < NROWS; r++){
            var oneRow = new ArrayList<GameElement>();
            rows.add(oneRow);
            for(int c = 0; c < NCOLS; c++){
                oneRow.add(new Enemy(
                    c * ENEMY_SIZE * 2, r * ENEMY_SIZE * 2, ENEMY_SIZE, Color.yellow, true
                ));
                enemies++;
            }
        }
    }

    @Override
    public void render(Graphics2D g2) {
        //render enemy array
        for(var r: rows){
            for(var e: r){
                e.render(g2);
            }
        }

        //render bombs
        for(var b: bombs){
            b.render(g2);
        }
        
    }

    @Override
    public void animate() {
        int dx;
        if(kills >= 10){
            dx = UNIT_MOVE*2;
        }else {
            dx = UNIT_MOVE;
        }

        if(movingToRight){
            if (rightEnd() >= GameBoard.WIDTH){
                dx = -dx;
                movingToRight = false;
                
                //update y loc
                for(var row: rows){
                    for(var e: row){
                        e.y += ENEMY_SIZE;
                    }
                }
            }
        }else{
            dx = -dx;
            if(leftEnd() <= 0) {
                dx = -dx;
                movingToRight = true;
                
                //update y loc
                for(var row: rows){
                    for(var e: row){
                        e.y += ENEMY_SIZE;
                    }
                }
            }
        }

        //update x loc
        for(var row: rows){
            for(var e: row){
                e.x += dx;
            }
        }
        
        //animate bombs
        for(var b: bombs){
            b.animate();
        }
    }

    private int rightEnd(){
        int xEnd = -100;
        for(var row: rows){
            if(row.size() == 0) continue;
            int x = row.get(row.size()-1).x + ENEMY_SIZE;
            if(x > xEnd) xEnd = x;
        }
        return xEnd;
    }

    private int leftEnd(){
        int xEnd = 9000;
        for(var row: rows){
            if(row.size() == 0) continue;
            int x = row.get(0).x;
            if(x < xEnd) xEnd = x;
        }
        return xEnd;
    }

    public void dropBombs(){
        for(var row: rows){
            for (var e: row){
                if(random.nextFloat() < 0.1F) {
                    Bomb bomb = new Bomb(e.x, e.y);
                    if(random.nextBoolean()){
                        bomb.setStrat(new RegBomb());
                    }else{
                        bomb.setStrat(new WideBomb());
                    }
                    //bombs.add(new Bomb(e.x, e.y));
                    bombs.add(bomb);
                }
            }
        }
    }

    public void removeBombsOutOfBound() {
        var remove = new ArrayList<GameElement>();
        for(var b: bombs){
            if(b.y >= GameBoard.HEIGHT) remove.add(b);  
        }
        bombs.removeAll(remove);
    }

    public boolean isEnemeyOutOfBounds(){
        for(var row: rows){
            for(var e: row){
                if(e.y >= GameBoard.HEIGHT - ENEMY_SIZE){
                    return true;
                }
            }
        }
        return false;
    }

    public void processCollision(Shooter shooter, Defence defence){
        var removeBullets = new ArrayList<GameElement>();
        
        // bullets vs enemies
        for(var row: rows){
            var removeEnemies = new ArrayList<GameElement>();
            for(var enemy: row){
                int added = 0;
                for(var bullet: shooter.getWeapons()){
                    if(enemy.collideWith(bullet)){
                        removeBullets.add(bullet);
                        removeEnemies.add(enemy);
                        added++;
                        if(added <= 1){
                            kills++;  
                        }
                    }
                }
            }
            row.removeAll(removeEnemies);
        }
        shooter.getWeapons().removeAll(removeBullets);

        //bullets vs bombs
        var removeBombs = new ArrayList<GameElement>();
        removeBullets.clear();
        for(var b: bombs){
            for(var bullet: shooter.getWeapons()){
                if(b.collideWith(bullet)){
                    removeBombs.add(b);
                    removeBullets.add(bullet);
                }
            }
        }

        shooter.getWeapons().removeAll(removeBullets);
        bombs.removeAll(removeBombs);

        //bombs vs shooter
        var removeComponents = new ArrayList<GameElement>();
        removeBombs.clear();
        for(var b: bombs){
            for(var c: shooter.getComponents()){
                if(b.collideWith(c)){
                    removeComponents.add(c);
                    removeBombs.add(b);
                    shooter.setDeaths(shooter.getDeaths()+1);
                }
            }
        }

        shooter.getComponents().removeAll(removeComponents);
        bombs.removeAll(removeBombs);


        //bombs vs walls
        var removeWall = new ArrayList<GameElement>();
        removeBombs.clear();
        for(var b: bombs){
            for(var w: defence.getWalls()){
                if(b.collideWith(w)){
                    removeWall.add(w);
                    removeBombs.add(b);
                }
            }
        }

        defence.getWalls().removeAll(removeWall);
        bombs.removeAll(removeBombs);
    }
//----------------------------------------------------------------------------------------------
    public void processCollision2(Shooter shooter, Defence defence, Shooter addS){
        var removeBullets = new ArrayList<GameElement>();
        var removeBullets2 = new ArrayList<GameElement>();
        
        // bullets vs enemies
        for(var row: rows){
            var removeEnemies = new ArrayList<GameElement>();
            for(var enemy: row){
                int added = 0;
                for(var bullet: shooter.getWeapons()){
                    if(enemy.collideWith(bullet)){
                        removeBullets.add(bullet);
                        removeEnemies.add(enemy);
                        added++;
                        if(added <= 1){
                            kills++;  
                        }
                    }
                }
                //addS shooter
                for(var bullet: addS.getWeapons()){
                    if(enemy.collideWith(bullet)){
                        removeBullets2.add(bullet);
                        removeEnemies.add(enemy);
                        added++;
                        if(added <= 1){
                            kills++;  
                        }
                    }
                }
            }
            row.removeAll(removeEnemies);
        }
        shooter.getWeapons().removeAll(removeBullets);
        addS.getWeapons().removeAll(removeBullets2);

        //bullets vs bombs
        var removeBombs = new ArrayList<GameElement>();
        removeBullets.clear();
        for(var b: bombs){
            for(var bullet: shooter.getWeapons()){
                if(b.collideWith(bullet)){
                    removeBombs.add(b);
                    removeBullets.add(bullet);
                }
            }
            //addS shooter
            for(var bullet: addS.getWeapons()){
                if(b.collideWith(bullet)){
                    removeBombs.add(b);
                    removeBullets.add(bullet);
                }
            }

        }
        addS.getWeapons().removeAll(removeBullets2);
        shooter.getWeapons().removeAll(removeBullets);
        bombs.removeAll(removeBombs);

        //bombs vs shooter
        var removeComponents = new ArrayList<GameElement>();
        //var removeComponents2 = new ArrayList<GameElement>();
        removeBombs.clear();
        for(var b: bombs){
            for(var c: shooter.getComponents()){
                if(b.collideWith(c)){
                    removeComponents.add(c);
                    removeBombs.add(b);
                    shooter.setDeaths(shooter.getDeaths()+1);
                }
            }
            /*for(var c: addS.getComponents()){
                if(b.collideWith(c)){
                    removeComponents2.add(c);
                    removeBombs.add(b);
                    addS.setDeaths(addS.getDeaths()+1);
                }
            }*/

        }
        //addS.getComponents().removeAll(removeComponents2);
        shooter.getComponents().removeAll(removeComponents);
        bombs.removeAll(removeBombs);

        //bombs vs walls
        var removeWall = new ArrayList<GameElement>();
        removeBombs.clear();
        for(var b: bombs){
            for(var w: defence.getWalls()){
                if(b.collideWith(w)){
                    removeWall.add(w);
                    removeBombs.add(b);
                }
            }
        }

        defence.getWalls().removeAll(removeWall);
        bombs.removeAll(removeBombs);
    }

    public boolean noMoreEnemeys(){
        if(kills == enemies){
            return true;
        }else{
            return false;
        }
    }
// subject -------------------------------------------------------------------------------------
    @Override
    public void register(Observer o) {
        observers.add(o);
    }

    @Override
    public void deregister(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObserver() {
        for(Observer o: observers){
            o.computeScore(kills);
        }
    }

    
}
