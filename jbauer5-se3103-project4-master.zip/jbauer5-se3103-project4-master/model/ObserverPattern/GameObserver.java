package model.ObserverPattern;

import view.GameBoard;

public class GameObserver implements Observer{
    private GameBoard gameBoard;

    public GameObserver(GameBoard gameBoard){
        this.gameBoard = gameBoard;
    }

    @Override
    public void computeScore(int kills) {
        gameBoard.setScore(kills*GameBoard.POINTS);
        gameBoard.getScoreText().updateText("Score:"+kills*GameBoard.POINTS);
        
    }
    
}
