package model.ObserverPattern;

public interface Observer {
    
    public void computeScore(int kills);
}
