package model;

import java.awt.Color;
import java.awt.Graphics2D;

import model.StrategyPattern.Strategy;

public class Bomb extends GameElement{

    public static final int SIZE = 5;
    public static final int UNIT_MOVE = 5;
    private Strategy strat;

    public Bomb(int x, int y){
        super(x, y, Color.green, true, SIZE, SIZE*2);
    }

    public void setStrat(Strategy strat){
        this.strat = strat;
    }

    @Override
    public void render(Graphics2D g2) {
        strat.bombRender(g2, x, y, color, filled, width, height);
    }

    @Override
    public void animate() {
        super.y += UNIT_MOVE;
        
    }
    
}
