package model;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;

public class Defence extends GameElement{
    
    public static final int NBLOCKS = 15;

    private ArrayList<GameElement> walls = new ArrayList<>();


    public Defence(int x, int y){
        super(x, y, 0, 0);
        
        int size = DefenceElement.SIZE;
        
        //create array of walls
        int b = 0;
        for(int w = 0; w < NBLOCKS; w++){
            if(w == 3 || w == 6 || w == 9 || w == 12) b++;
            walls.add(new DefenceElement(x-(size*w)-(40*b), y, Color.blue, false));
        }

    }

    @Override
    public void render(Graphics2D g2) {
        for(var w: walls){
            w.render(g2);
        }     
    }

    @Override
    public void animate() { }

    public ArrayList<GameElement> getWalls() {
        return walls;
    }
    
}
