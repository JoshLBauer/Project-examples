package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import controller.KeyController;
import controller.TimerListener;
import model.Defence;
import model.DefenceElement;
import model.EnemyComposite;
import model.Shooter;
import model.ShooterElement;


public class GameBoard {

    public static final int WIDTH = 600;
    public static final int HEIGHT = 300;

    public static final int FPS = 20;
    public static final int DELAY = 1000 / FPS; 
    public static final int POINTS = 10;

    private JFrame window;
    private MyCanvas canvas;
    private Shooter shooter;
    private Shooter addS;
    private Defence defence;
    private EnemyComposite enemyComposite;
    private Timer timer;
    private TimerListener timerListener;
    private int score = 0;
    private TextDraw scoreText = new TextDraw("Score:"+score, 5, 15, Color.yellow, 15);

    public GameBoard(JFrame window){
        this.window = window;
    }

    public void init(){
        Container cp = window.getContentPane();

        canvas = new MyCanvas(this, WIDTH, HEIGHT);
        cp.add(BorderLayout.CENTER, canvas);
        canvas.addKeyListener(new KeyController(this));
        canvas.requestFocusInWindow();
        canvas.setFocusable(true);

        JButton startButton = new JButton("Start");
        JButton quitButton = new JButton("Quit");
        startButton.setFocusable(false);
        quitButton.setFocusable(false);

        JPanel southPanel = new JPanel();
        southPanel.add(startButton);
        southPanel.add(quitButton);
        cp.add(BorderLayout.SOUTH, southPanel);

        canvas.getGameElements().add(new TextDraw("Click <Start> to Play", 100, 100, Color.yellow, 30));
        
        timerListener = new TimerListener(this);
        timer = new Timer(DELAY, timerListener);  //timer

        startButton.addActionListener(event -> {
            shooter = new Shooter(GameBoard.WIDTH / 2, GameBoard.HEIGHT - ShooterElement.SIZE);
            addS = null;
            timerListener.setBonus(0);
            defence = new Defence(GameBoard.WIDTH - DefenceElement.SIZE - 80, GameBoard.HEIGHT - 75);
            enemyComposite = new EnemyComposite();
            canvas.getGameElements().clear();
            score = 0;
            canvas.getGameElements().add(scoreText);
            canvas.getGameElements().add(shooter);
            canvas.getGameElements().add(defence);
            canvas.getGameElements().add(enemyComposite);
            timer.start();
        });

        quitButton.addActionListener(event -> System.exit(0));

    }

    public MyCanvas getCanvas() {
        return canvas;
    }

    public Timer getTimer() {
        return timer;
    }

    public TimerListener getTimerListener() {
        return timerListener;
    }

    public Shooter getShooter() {
        return shooter;
    }

    public EnemyComposite getEnemyComposite() {
        return enemyComposite;
    }

    public static int getHeight() {
        return HEIGHT;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public TextDraw getScoreText() {
        return scoreText;
    }

    public Defence getDefence() {
        return defence;
    }

    public Shooter getAddS() {
        return addS;
    }

    public void setAddS(int x, int y, int dist){
        addS = new Shooter(x, y, dist);
    }


}
